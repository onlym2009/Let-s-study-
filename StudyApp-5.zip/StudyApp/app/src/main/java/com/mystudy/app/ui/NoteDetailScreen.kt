package com.mystudy.app.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mystudy.app.data.Attachment
import com.mystudy.app.data.AttachmentType
import com.mystudy.app.data.NoteDetailViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailScreen(noteId: Long, noteName: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val vm: NoteDetailViewModel = viewModel(factory = NoteDetailViewModel.Factory(app, noteId))
    val attachments by vm.attachments.asLiveData().observeAsState(emptyList())

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { vm.addAttachment(it, AttachmentType.IMAGE) }
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.addAttachment(it, AttachmentType.PDF) }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.addAttachment(it, AttachmentType.AUDIO) }
    }

    var showAddMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(noteName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        },
        floatingActionButton = {
            Box {
                FloatingActionButton(onClick = { showAddMenu = true }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة ملف")
                }
                DropdownMenu(expanded = showAddMenu, onDismissRequest = { showAddMenu = false }) {
                    DropdownMenuItem(text = { Text("صورة") }, leadingIcon = { Icon(Icons.Default.Image, null) }, onClick = {
                        showAddMenu = false
                        imagePicker.launch("image/*")
                    })
                    DropdownMenuItem(text = { Text("ملف PDF") }, leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) }, onClick = {
                        showAddMenu = false
                        pdfPicker.launch(arrayOf("application/pdf"))
                    })
                    DropdownMenuItem(text = { Text("ملف صوتي") }, leadingIcon = { Icon(Icons.Default.Mic, null) }, onClick = {
                        showAddMenu = false
                        audioPicker.launch(arrayOf("audio/*"))
                    })
                }
            }
        }
    ) { padding ->
        if (attachments.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("مفيش ملفات لسه. دوس + عشان تضيف صورة أو PDF أو صوت")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(attachments, key = { it.id }) { att ->
                    AttachmentCard(att, onOpen = { openAttachment(context, att) }, onDelete = { vm.deleteAttachment(att) })
                }
            }
        }
    }
}

@Composable
fun AttachmentCard(attachment: Attachment, onOpen: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val icon = when (attachment.type) {
                AttachmentType.IMAGE -> Icons.Default.Image
                AttachmentType.PDF -> Icons.Default.PictureAsPdf
                AttachmentType.AUDIO -> Icons.Default.Mic
            }
            Icon(icon, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Text(attachment.fileName, modifier = Modifier.weight(1f))
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "حذف")
            }
        }
    }
}

private fun openAttachment(context: android.content.Context, attachment: Attachment) {
    val file = File(attachment.filePath)
    if (!file.exists()) return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val mime = when (attachment.type) {
        AttachmentType.IMAGE -> "image/*"
        AttachmentType.PDF -> "application/pdf"
        AttachmentType.AUDIO -> "audio/*"
    }
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    // Always show the system "open with" chooser so the user picks which installed app handles it.
    val chooser = Intent.createChooser(intent, "فتح باستخدام").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        context.startActivity(chooser)
    } catch (e: Exception) {
        // No app available to open this file type
    }
}

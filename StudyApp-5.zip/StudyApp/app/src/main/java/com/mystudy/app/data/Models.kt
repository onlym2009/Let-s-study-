package com.mystudy.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "lecture_notes",
    foreignKeys = [ForeignKey(
        entity = Subject::class,
        parentColumns = ["id"],
        childColumns = ["subjectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class LectureNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

enum class AttachmentType { IMAGE, PDF, AUDIO }

@Entity(
    tableName = "attachments",
    foreignKeys = [ForeignKey(
        entity = LectureNote::class,
        parentColumns = ["id"],
        childColumns = ["noteId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("noteId")]
)
data class Attachment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noteId: Long,
    val filePath: String,
    val fileName: String,
    val type: AttachmentType,
    val addedAt: Long = System.currentTimeMillis()
)

/** Which weekly table an entry belongs to: study schedule or lectures/appointments timetable. */
enum class WeeklyCategory { STUDY, LECTURE }

/**
 * A single free-text entry placed under one day of the week (Saturday=1 ... Friday=7),
 * inside either the study schedule or the lecture/appointment timetable.
 */
@Entity(tableName = "weekly_entries")
data class WeeklyEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: WeeklyCategory,
    val dayOfWeek: Int, // 1 = Saturday ... 7 = Friday
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

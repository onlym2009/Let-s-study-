package com.mystudy.app.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mystudy.app.data.WeeklyCategory
import com.mystudy.app.data.WeeklyEntry
import com.mystudy.app.data.WeeklyViewModel

private val DAY_NAMES = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")

@Composable
fun StudyScheduleScreen() {
    WeeklyScreen(title = "جدول المذاكرة", category = WeeklyCategory.STUDY)
}

@Composable
fun TimetableScreen() {
    WeeklyScreen(title = "جدول المحاضرات", category = WeeklyCategory.LECTURE)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WeeklyScreen(title: String, category: WeeklyCategory) {
    val app = LocalContext.current.applicationContext as Application
    val vm: WeeklyViewModel = viewModel(factory = WeeklyViewModel.Factory(app, category))
    val entries by vm.entries.asLiveData().observeAsState(emptyList())
    var openDay by remember { mutableStateOf<Int?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text(title) }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(DAY_NAMES) { index, dayName ->
                val dayNumber = index + 1
                val dayEntries = entries.filter { it.dayOfWeek == dayNumber }
                DayCard(
                    dayName = dayName,
                    entries = dayEntries,
                    isOpen = openDay == dayNumber,
                    onToggle = { openDay = if (openDay == dayNumber) null else dayNumber },
                    onAdd = { text -> vm.addEntry(dayNumber, text); openDay = null },
                    onDelete = { vm.deleteEntry(it) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DayCard(
    dayName: String,
    entries: List<WeeklyEntry>,
    isOpen: Boolean,
    onToggle: () -> Unit,
    onAdd: (String) -> Unit,
    onDelete: (WeeklyEntry) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(dayName, style = MaterialTheme.typography.titleSmall)
                IconButton(onClick = onToggle, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة")
                }
            }

            entries.forEach { entry ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(entry.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { onDelete(entry) }, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "حذف", modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (entries.isEmpty() && !isOpen) {
                Text(
                    "مفيش حاجة لسه",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (isOpen) {
                var text by remember { mutableStateOf("") }
                val focusRequester = remember { FocusRequester() }
                LaunchedEffect(Unit) { focusRequester.requestFocus() }

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("اكتب هنا (مثلا: 6 م - فسيولوجي)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .focusRequester(focusRequester)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { if (text.isNotBlank()) onAdd(text) }, modifier = Modifier.weight(1f)) {
                        Text("إضافة")
                    }
                    OutlinedButton(onClick = onToggle, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

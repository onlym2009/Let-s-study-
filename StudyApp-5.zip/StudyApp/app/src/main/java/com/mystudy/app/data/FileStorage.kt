package com.mystudy.app.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

object FileStorage {

    private fun attachmentsDir(context: Context): File {
        val dir = File(context.filesDir, "attachments")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Copies the content at [uri] into app-private storage and returns (localPath, displayName). */
    fun copyToLocalStorage(context: Context, uri: Uri, originalName: String?): Pair<String, String> {
        val name = originalName ?: "file_${System.currentTimeMillis()}"
        val safeName = "${UUID.randomUUID()}_$name"
        val destFile = File(attachmentsDir(context), safeName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return destFile.absolutePath to name
    }

    fun getDisplayNameFromUri(context: Context, uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && nameIndex >= 0) {
                name = it.getString(nameIndex)
            }
        }
        return name
    }

    fun delete(path: String) {
        val f = File(path)
        if (f.exists()) f.delete()
    }
}

package com.mystudy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mystudy.app.ui.AppNavHost
import com.mystudy.app.ui.LetsStudyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LetsStudyTheme {
                Surface(modifier = Modifier) {
                    AppNavHost()
                }
            }
        }
    }
}

package com.mystudy.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Subject>>

    @Insert
    suspend fun insert(subject: Subject): Long

    @Delete
    suspend fun delete(subject: Subject)
}

@Dao
interface LectureNoteDao {
    @Query("SELECT * FROM lecture_notes WHERE subjectId = :subjectId ORDER BY createdAt DESC")
    fun getForSubject(subjectId: Long): Flow<List<LectureNote>>

    @Insert
    suspend fun insert(note: LectureNote): Long

    @Delete
    suspend fun delete(note: LectureNote)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments WHERE noteId = :noteId ORDER BY addedAt ASC")
    fun getForNote(noteId: Long): Flow<List<Attachment>>

    @Insert
    suspend fun insert(attachment: Attachment): Long

    @Delete
    suspend fun delete(attachment: Attachment)
}

@Dao
interface WeeklyEntryDao {
    @Query("SELECT * FROM weekly_entries WHERE category = :category ORDER BY dayOfWeek ASC, createdAt ASC")
    fun getByCategory(category: WeeklyCategory): Flow<List<WeeklyEntry>>

    @Insert
    suspend fun insert(entry: WeeklyEntry): Long

    @Delete
    suspend fun delete(entry: WeeklyEntry)
}

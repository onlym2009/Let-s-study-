package com.mystudy.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF4FA3E3)
private val AccentDark = Color(0xFF2E7DC2)
private val AccentSoft = Color(0xFFDCEEFB)
private val Background = Color(0xFFEAF4FC)
private val Surface = Color(0xFFF5FAFE)
private val CardWhite = Color(0xFFFFFFFF)

private val LetsStudyColors = lightColorScheme(
    primary = Accent,
    onPrimary = CardWhite,
    primaryContainer = AccentSoft,
    onPrimaryContainer = AccentDark,
    secondary = AccentDark,
    background = Background,
    onBackground = AccentDark,
    surface = Surface,
    onSurface = AccentDark,
    surfaceVariant = AccentSoft,
    onSurfaceVariant = AccentDark
)

@Composable
fun LetsStudyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LetsStudyColors, content = content)
}

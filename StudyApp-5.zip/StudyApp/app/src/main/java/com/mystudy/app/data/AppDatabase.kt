package com.mystudy.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun fromAttachmentType(value: AttachmentType): String = value.name

    @TypeConverter
    fun toAttachmentType(value: String): AttachmentType = AttachmentType.valueOf(value)

    @TypeConverter
    fun fromWeeklyCategory(value: WeeklyCategory): String = value.name

    @TypeConverter
    fun toWeeklyCategory(value: String): WeeklyCategory = WeeklyCategory.valueOf(value)
}

@Database(
    entities = [Subject::class, LectureNote::class, Attachment::class, WeeklyEntry::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun lectureNoteDao(): LectureNoteDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun weeklyEntryDao(): WeeklyEntryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "study_app.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

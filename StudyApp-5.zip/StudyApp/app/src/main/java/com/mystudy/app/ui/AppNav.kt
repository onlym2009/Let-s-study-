package com.mystudy.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType

private const val ROUTE_SUBJECTS = "subjects"
private const val ROUTE_STUDY_SCHEDULE = "study_schedule"
private const val ROUTE_TIMETABLE = "timetable"
private const val ROUTE_SUBJECT_DETAIL = "subject_detail/{subjectId}/{subjectName}"
private const val ROUTE_NOTE_DETAIL = "note_detail/{noteId}/{noteName}"

@Composable
fun AppNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { AppBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = ROUTE_SUBJECTS,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(ROUTE_SUBJECTS) {
                SubjectsScreen(onOpenSubject = { id, name ->
                    navController.navigate("subject_detail/$id/${Uri.encode(name)}")
                })
            }
            composable(ROUTE_STUDY_SCHEDULE) { StudyScheduleScreen() }
            composable(ROUTE_TIMETABLE) { TimetableScreen() }
            composable(
                ROUTE_SUBJECT_DETAIL,
                arguments = listOf(
                    navArgument("subjectId") { type = NavType.LongType },
                    navArgument("subjectName") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("subjectId") ?: 0L
                val name = backStackEntry.arguments?.getString("subjectName") ?: ""
                SubjectDetailScreen(
                    subjectId = id,
                    subjectName = name,
                    onOpenNote = { noteId, noteName ->
                        navController.navigate("note_detail/$noteId/${Uri.encode(noteName)}")
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                ROUTE_NOTE_DETAIL,
                arguments = listOf(
                    navArgument("noteId") { type = NavType.LongType },
                    navArgument("noteName") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("noteId") ?: 0L
                val name = backStackEntry.arguments?.getString("noteName") ?: ""
                NoteDetailScreen(noteId = id, noteName = name, onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun AppBottomBar(navController: androidx.navigation.NavController) {
    val items = listOf(
        Triple(ROUTE_SUBJECTS, "المواد", Icons.Default.MenuBook),
        Triple(ROUTE_STUDY_SCHEDULE, "جدول المذاكرة", Icons.Default.CalendarMonth),
        Triple(ROUTE_TIMETABLE, "المحاضرات والمواعيد", Icons.Default.Event)
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar {
        items.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = currentDestination?.hierarchy?.any { it.route == route } == true,
                onClick = {
                    navController.navigate(route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) }
            )
        }
    }
}

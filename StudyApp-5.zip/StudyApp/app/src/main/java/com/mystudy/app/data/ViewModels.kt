package com.mystudy.app.data

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class SubjectsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).subjectDao()
    val subjects = dao.getAll()

    fun addSubject(name: String) = viewModelScope.launch {
        if (name.isNotBlank()) dao.insert(Subject(name = name.trim()))
    }

    fun deleteSubject(subject: Subject) = viewModelScope.launch {
        dao.delete(subject)
    }
}

class SubjectDetailViewModel(app: Application, private val subjectId: Long) : AndroidViewModel(app) {
    private val db = AppDatabase.getInstance(app)
    val notes = db.lectureNoteDao().getForSubject(subjectId)

    fun addNote(name: String) = viewModelScope.launch {
        if (name.isNotBlank()) db.lectureNoteDao().insert(LectureNote(subjectId = subjectId, name = name.trim()))
    }

    fun deleteNote(note: LectureNote) = viewModelScope.launch {
        db.lectureNoteDao().delete(note)
    }

    class Factory(private val app: Application, private val subjectId: Long) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return SubjectDetailViewModel(app, subjectId) as T
        }
    }
}

class NoteDetailViewModel(app: Application, private val noteId: Long) : AndroidViewModel(app) {
    private val db = AppDatabase.getInstance(app)
    val attachments = db.attachmentDao().getForNote(noteId)

    fun addAttachment(uri: Uri, type: AttachmentType) = viewModelScope.launch {
        val context = getApplication<Application>()
        val displayName = FileStorage.getDisplayNameFromUri(context, uri)
        val (path, name) = FileStorage.copyToLocalStorage(context, uri, displayName)
        db.attachmentDao().insert(Attachment(noteId = noteId, filePath = path, fileName = name, type = type))
    }

    fun deleteAttachment(attachment: Attachment) = viewModelScope.launch {
        db.attachmentDao().delete(attachment)
        FileStorage.delete(attachment.filePath)
    }

    class Factory(private val app: Application, private val noteId: Long) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return NoteDetailViewModel(app, noteId) as T
        }
    }
}

/** Backs both the study-schedule tab and the lectures/appointments tab (differ only by [category]). */
class WeeklyViewModel(app: Application, private val category: WeeklyCategory) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).weeklyEntryDao()
    val entries = dao.getByCategory(category)

    fun addEntry(dayOfWeek: Int, text: String) = viewModelScope.launch {
        if (text.isNotBlank()) {
            dao.insert(WeeklyEntry(category = category, dayOfWeek = dayOfWeek, text = text.trim()))
        }
    }

    fun deleteEntry(entry: WeeklyEntry) = viewModelScope.launch {
        dao.delete(entry)
    }

    class Factory(private val app: Application, private val category: WeeklyCategory) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return WeeklyViewModel(app, category) as T
        }
    }
}
